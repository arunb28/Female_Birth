# Daily-Births-Forecasting-Prediction-using-Facebook-Prophet


Context

A time series dataset depicting the total number of female births recording in California, USA during the year of 1959.

Content 

This is a very basic time series dataset, with only the date ("dd/mm/yyyy" format), and the number of births. There are 365 records in total.
